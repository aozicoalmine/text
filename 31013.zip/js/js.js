$('nav>ul>li').hover(function () { 
    $('.submenu').stop().slideToggle(); 
});